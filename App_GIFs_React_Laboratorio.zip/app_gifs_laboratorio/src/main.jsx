import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const API_KEY = import.meta.env.VITE_GIPHY_API_KEY || "";
const CATEGORIES = ["dragon ball", "valorant", "one punch man"];

function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [categoryResults, setCategoryResults] = useState({});
  const [loading, setLoading] = useState(false);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [error, setError] = useState("");
  const [selectedGif, setSelectedGif] = useState(null);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(false);

  async function requestGifs(term, start = 0, limit = 12) {
    if (!API_KEY) throw new Error("Falta configurar la clave API de GIPHY. Revisa el archivo .env.local.");
    const params = new URLSearchParams({
      api_key: API_KEY,
      q: term,
      limit: String(limit),
      offset: String(start),
      rating: "g",
      lang: "es"
    });
    const response = await fetch(`https://api.giphy.com/v1/gifs/search?${params}`);
    if (!response.ok) throw new Error(`GIPHY respondió con el código ${response.status}. Verifica tu API Key.`);
    return response.json();
  }

  useEffect(() => {
    let active = true;
    async function loadCategories() {
      setLoadingCategories(true);
      setError("");
      try {
        const entries = await Promise.all(CATEGORIES.map(async (category) => {
          const data = await requestGifs(category, 0, 5);
          return [category, data.data || []];
        }));
        if (active) setCategoryResults(Object.fromEntries(entries));
      } catch (err) {
        if (active) setError(err.message);
      } finally {
        if (active) setLoadingCategories(false);
      }
    }
    loadCategories();
    return () => { active = false; };
  }, []);

  async function search(term = query, start = 0) {
    const clean = term.trim();
    if (!clean) {
      setQuery("");
      setResults([]);
      setOffset(0);
      setHasMore(false);
      return;
    }
    setLoading(true);
    setError("");
    try {
      const data = await requestGifs(clean, start, 24);
      setResults(start === 0 ? (data.data || []) : [...results, ...(data.data || [])]);
      setOffset(start);
      setHasMore(Boolean(data.pagination && start + data.pagination.count < data.pagination.total_count));
    } catch (err) {
      setError(err.message);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  function chooseCategory(category) {
    setQuery(category);
    setResults([]);
    setOffset(0);
    search(category, 0);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function GifCard({ gif }) {
    const image = gif.images?.fixed_width || gif.images?.downsized;
    return (
      <button className="gif-card" onClick={() => setSelectedGif(gif)} title="Ver GIF">
        <img src={image?.url} alt={gif.title || "GIF"} loading="lazy" />
        <span>{gif.title || "GIF sin título"}</span>
      </button>
    );
  }

  return (
    <main className="app">
      <header className="top">
        <h1>App de gifs</h1>
        <form className="search-form" onSubmit={(event) => { event.preventDefault(); search(query, 0); }}>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar gifs"
            aria-label="Buscar GIFs"
            maxLength={50}
          />
          <button type="submit" disabled={loading}>Buscar</button>
        </form>
      </header>

      {error && <div className="alert" role="alert">{error}</div>}

      {query.trim() ? (
        <section className="section">
          <h2>{query}</h2>
          {loading && <p className="status">Buscando GIFs...</p>}
          {!loading && results.length === 0 && !error && <p className="status">No se encontraron GIFs. Prueba otra búsqueda.</p>}
          <div className="gif-grid">
            {results.map((gif) => <GifCard key={gif.id} gif={gif} />)}
          </div>
          {hasMore && <button className="more-button" disabled={loading} onClick={() => search(query, offset + 24)}>Cargar más</button>}
          <button className="back-button" onClick={() => { setQuery(""); setResults([]); }}>Ver categorías</button>
        </section>
      ) : (
        <section>
          {loadingCategories && <p className="status">Cargando categorías...</p>}
          {CATEGORIES.map((category) => (
            <section className="section" key={category}>
              <h2><button className="category-link" onClick={() => chooseCategory(category)}>{category}</button></h2>
              <div className="gif-grid">
                {(categoryResults[category] || []).map((gif) => <GifCard key={gif.id} gif={gif} />)}
              </div>
            </section>
          ))}
        </section>
      )}

      <footer>GIFs proporcionados por <a href="https://giphy.com/" target="_blank" rel="noreferrer">GIPHY</a></footer>

      {selectedGif && (
        <div className="modal" role="dialog" aria-modal="true" onClick={() => setSelectedGif(null)}>
          <div className="modal-content" onClick={(event) => event.stopPropagation()}>
            <button className="close" onClick={() => setSelectedGif(null)} aria-label="Cerrar">×</button>
            <img src={selectedGif.images?.original?.url} alt={selectedGif.title || "GIF seleccionado"} />
            <p>{selectedGif.title || "GIF seleccionado"}</p>
            <a href={selectedGif.url} target="_blank" rel="noreferrer">Abrir en GIPHY ↗</a>
          </div>
        </div>
      )}
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);